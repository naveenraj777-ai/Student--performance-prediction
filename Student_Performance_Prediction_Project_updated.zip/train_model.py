# Step 17 onwards: train/test split, model training, prediction and evaluation
from pathlib import Path
import argparse
import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score, accuracy_score, classification_report

ROOT = Path(__file__).resolve().parent
DATA_PATH = ROOT / "cleaned_student_performance.csv"
MODEL_PATH = ROOT / "model.pkl"
METRICS_PATH = ROOT / "model_metrics.txt"

def main():
    parser = argparse.ArgumentParser(description="Train a student-performance ML model.")
    parser.add_argument("--target", default="Performance Index", help="Target column name in CSV.")
    args = parser.parse_args()

    data_path = DATA_PATH if DATA_PATH.exists() else ROOT / "student_performance.csv"
    df = pd.read_csv(data_path)
    target = args.target
    if target not in df.columns:
        print("Target column not found.")
        print("Available columns:", list(df.columns))
        print("Run: python train_model.py --target \"YOUR COLUMN\"")
        return
    df = df.drop_duplicates()
    df = df.dropna(subset=[target])
    X = df.drop(columns=[target])
    y = df[target]
    if X.empty:
        print("No feature columns found.")
        return

    is_regression = pd.api.types.is_numeric_dtype(y) and y.nunique() > 10
    numeric_features = X.select_dtypes(include="number").columns.tolist()
    categorical_features = X.select_dtypes(exclude="number").columns.tolist()
    numeric_pipe = Pipeline([("imputer", SimpleImputer(strategy="median")), ("scaler", StandardScaler())])
    categorical_pipe = Pipeline([("imputer", SimpleImputer(strategy="most_frequent")), ("encoder", OneHotEncoder(handle_unknown="ignore"))])
    transformers = []
    if numeric_features: transformers.append(("numeric", numeric_pipe, numeric_features))
    if categorical_features: transformers.append(("categorical", categorical_pipe, categorical_features))
    preprocessor = ColumnTransformer(transformers=transformers)

    model = RandomForestRegressor(n_estimators=150, random_state=42) if is_regression else RandomForestClassifier(n_estimators=150, random_state=42)
    pipeline = Pipeline([("preprocessor", preprocessor), ("model", model)])
    stratify = None if is_regression or y.value_counts().min() < 2 else y
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=stratify)
    pipeline.fit(X_train, y_train)
    predictions = pipeline.predict(X_test)

    lines = [f"Target column: {target}", f"Model: {'RandomForestRegressor' if is_regression else 'RandomForestClassifier'}", f"Training rows: {len(X_train)}", f"Testing rows: {len(X_test)}"]
    if is_regression:
        mae=mean_absolute_error(y_test,predictions)
        rmse=mean_squared_error(y_test,predictions)**0.5
        r2=r2_score(y_test,predictions)
        lines += [f"MAE: {mae:.3f}", f"RMSE: {rmse:.3f}", f"R2: {r2:.3f}"]
    else:
        acc=accuracy_score(y_test,predictions)
        lines += [f"Accuracy: {acc:.3f}", "Classification report:", classification_report(y_test,predictions,zero_division=0)]
    joblib.dump({"pipeline":pipeline,"target":target,"features":list(X.columns),"regression":is_regression},MODEL_PATH)
    METRICS_PATH.write_text("\n".join(lines),encoding="utf-8")
    print("\n".join(lines))
    print(f"\nModel saved to: {MODEL_PATH.name}")
    print(f"Metrics saved to: {METRICS_PATH.name}")

if __name__ == "__main__":
    main()
