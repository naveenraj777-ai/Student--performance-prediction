# Student Performance Prediction

## 1. Introduction
Student performance can be affected by academic habits, previous scores, sleep, practice and other factors. This project demonstrates how machine-learning techniques can analyze a dataset and estimate a performance measure.

## 2. Problem Statement
Develop a data-driven system that learns from student records and predicts a selected performance variable.

## 3. Objectives
- Inspect and clean a student dataset.
- Explore the data using graphs.
- Split data into training and testing sets.
- Train and evaluate a machine-learning model.
- Save the trained pipeline.
- Provide an interactive prediction interface.

## 4. Technologies Used
Python, Pandas, NumPy, Matplotlib, Seaborn, Scikit-learn, Joblib and Streamlit.

## 5. Dataset Description
Describe the source, number of rows, columns, feature names and target variable of the dataset actually used.

## 6. Data Preprocessing
Explain duplicate removal, handling missing numeric values using median and categorical values using the most-frequent value. Preprocessing is also incorporated into the model pipeline.

## 7. Exploratory Data Analysis
Insert the graphs generated in the `graphs` folder and explain what each graph shows.

## 8. Train-Test Split
The dataset is divided into training and testing portions (80% and 20%) using a fixed random state for repeatability.

## 9. Model
A Random Forest model is used. Regression is selected for numeric targets with many distinct values; otherwise classification is used.

## 10. Evaluation
For regression, record MAE, RMSE and R-squared. For classification, record accuracy and the classification report. Copy the actual results from `model_metrics.txt`.

## 11. Web Application
Describe the Streamlit interface and include screenshots of the input fields and prediction output.

## 12. Conclusion
Write a conclusion based on the actual evaluation results and observations.

## 13. Future Scope
The project can be improved with a larger and more diverse dataset, more models, additional features, validation and careful evaluation of fairness and limitations.

## 14. References
List the actual dataset source and relevant software/documentation sources.
