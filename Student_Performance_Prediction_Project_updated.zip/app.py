# Streamlit prediction app
from pathlib import Path
import joblib
import pandas as pd
import streamlit as st

ROOT=Path(__file__).resolve().parent
MODEL_PATH=ROOT/"model.pkl"
DATA_PATH=ROOT/"cleaned_student_performance.csv"

st.set_page_config(page_title="Student Performance Prediction",page_icon="🎓")
st.title("🎓 Student Performance Prediction")
st.write("Enter the student information below to generate a prediction.")

if not MODEL_PATH.exists():
    st.error("Trained model not found. Run python train_model.py first.")
    st.stop()

saved=joblib.load(MODEL_PATH)
pipeline=saved["pipeline"]
features=saved["features"]
regression=saved["regression"]

if DATA_PATH.exists():
    reference=pd.read_csv(DATA_PATH)
elif (ROOT/"student_performance.csv").exists():
    reference=pd.read_csv(ROOT/"student_performance.csv")
else:
    reference=None

inputs={}
for feature in features:
    if reference is not None and feature in reference.columns:
        series=reference[feature]
        if pd.api.types.is_numeric_dtype(series):
            default=float(series.median())
            inputs[feature]=st.number_input(feature,value=default)
        else:
            choices=sorted(series.dropna().astype(str).unique().tolist())
            inputs[feature]=st.selectbox(feature,choices if choices else ["Unknown"])
    else:
        inputs[feature]=st.text_input(feature)

if st.button("Predict Performance"):
    sample=pd.DataFrame([inputs],columns=features)
    result=pipeline.predict(sample)[0]
    st.success(f"Predicted result: {result}")
    if regression:
        st.caption("This is a model estimate, not a guarantee of a student's actual performance.")
