# Student Performance Prediction

A beginner-friendly machine-learning project that analyzes student data, creates exploratory graphs, trains a model, evaluates it, and provides predictions through Streamlit.

## Folder contents
- `student_performance.csv`: example dataset; replace with your own dataset if needed.
- `main.py`: data inspection, cleaning and EDA graphs.
- `train_model.py`: train/test split, model training, evaluation and model saving.
- `app.py`: Streamlit user interface.
- `Documentation/Project_Report.md`: report outline.
- `graphs/`: output charts.

## Setup in VS Code
1. Extract this ZIP.
2. Open the extracted folder in VS Code (File > Open Folder).
3. Open Terminal > New Terminal.
4. Create a virtual environment:
   - Windows: `py -m venv .venv`
   - Activate: `.venv\\Scripts\\Activate`
5. Install packages: `pip install -r requirements.txt`

## Run the project
1. EDA and cleaning: `python main.py`
2. Train model (default target is `Performance Index`): `python train_model.py`
3. If your target column has another name, run: `python train_model.py --target "Column Name"`
4. Launch web app: `streamlit run app.py`

## Dataset note
The included CSV is a small demonstration dataset created for practice. For a college submission, replace it with your actual dataset and rerun the analysis, training, and app. Document results from your own run; do not present demo metrics as real project results.
