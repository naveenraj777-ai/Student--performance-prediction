# Step 1-16: Data loading, cleaning, EDA, and graphs
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

ROOT = Path(__file__).resolve().parent
DATA_PATH = ROOT / "student_performance.csv"
GRAPH_DIR = ROOT / "graphs"
GRAPH_DIR.mkdir(exist_ok=True)

def main():
    if not DATA_PATH.exists():
        print(f"Dataset not found: {DATA_PATH}. Place your CSV in the project folder.")
        return
    df = pd.read_csv(DATA_PATH)
    print("\n--- Dataset Preview ---")
    print(df.head())
    print("\n--- Shape ---")
    print(df.shape)
    print("\n--- Data Types ---")
    print(df.dtypes)
    print("\n--- Missing Values ---")
    print(df.isnull().sum())
    print("\n--- Descriptive Statistics ---")
    print(df.describe(include="all").transpose())

    # Remove duplicate rows and fill missing values safely.
    df = df.drop_duplicates()
    for col in df.columns:
        if df[col].isna().any():
            if pd.api.types.is_numeric_dtype(df[col]):
                df[col] = df[col].fillna(df[col].median())
            else:
                mode = df[col].mode(dropna=True)
                df[col] = df[col].fillna(mode.iloc[0] if len(mode) else "Unknown")

    cleaned_path = ROOT / "cleaned_student_performance.csv"
    df.to_csv(cleaned_path, index=False)
    print(f"\nCleaned dataset saved: {cleaned_path.name}")

    sns.set_theme()
    numeric = df.select_dtypes(include="number")
    if not numeric.empty:
        plt.figure(figsize=(10,6))
        sns.heatmap(numeric.corr(), annot=True, cmap="coolwarm", fmt=".2f")
        plt.title("Correlation Heatmap")
        plt.tight_layout()
        plt.savefig(GRAPH_DIR / "correlation_heatmap.png")
        plt.close()

        for col in numeric.columns:
            plt.figure(figsize=(7,4))
            plt.hist(df[col].dropna(), bins=15, edgecolor="black")
            plt.title(f"Distribution: {col}")
            plt.tight_layout()
            plt.savefig(GRAPH_DIR / f"distribution_{col.replace(' ','_')}.png")
            plt.close()
    for col in df.select_dtypes(exclude="number").columns:
        plt.figure(figsize=(7,4))
        df[col].value_counts().plot(kind="bar")
        plt.title(f"Counts: {col}")
        plt.tight_layout()
        plt.savefig(GRAPH_DIR / f"counts_{col.replace(' ','_')}.png")
        plt.close()
    print(f"Graphs saved in {GRAPH_DIR}")
    print("\nEDA completed.")

if __name__ == "__main__":
    main()
